# q3ML v0.1.0

* Parse Selective Reaction Monitoring (SRM) Mass Spectrometry (MS) mzML files from Thermo Scientific
triple quadrupole mass spectrometers, which have been converted using pwiz version 3.0.2 and above.
