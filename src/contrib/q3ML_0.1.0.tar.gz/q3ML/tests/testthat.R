library(testthat)
library(q3ML)

test_check("q3ML")
