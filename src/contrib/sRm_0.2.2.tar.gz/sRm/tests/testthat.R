library(testthat)
library(sRm)

test_check("sRm")
