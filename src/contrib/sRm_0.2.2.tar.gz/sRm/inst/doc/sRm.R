## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- install, eval=FALSE-----------------------------------------------------
#  remotes::install_github('wilsontom/sRm')

## ---- load--------------------------------------------------------------------
library(sRm)

chrom_files <- list.files(system.file('extdata/Shimadzu_LCD', package = 'sRm'), full.names = TRUE)

srmExp <- openSRM(chrom_files, source_type = 'lcd', backend = 'mzR')

srmExp


## ---- plotSRM_overlay, fig.width = 6, fig.height = 4, fig.align = 'center'----
plotSRM(srmExp, index = 11, type = 'overlay')

## ---- plotSRM_facet, fig.width = 6, fig.height = 4,  fig.align = 'center'-----
plotSRM(srmExp, index = 11, type = 'facet')


## ---- plotParent,fig.width = 6, fig.height = 4,  fig.align = 'center'---------
plotParent(srmExp, 303)

## ---- peak_detection----------------------------------------------------------
srmExpPeaks <-
  detectPeaks(srmExp,
              snthresh = 5,
              peakwidth = c(5,75))

## ---- plotArea, fig.width = 6, fig.height = 4,  fig.align = 'center'----------
plotPeakArea(srmExpPeaks, index = 5, sampleName = 'QC02')

## ---- peak_grouping-----------------------------------------------------------
srmExpGroups <- groupPeaks(srmExpPeaks, rt_tolerance = 0.5)

## ---- group_summary-----------------------------------------------------------
group_table <- groupSummary(srmExpGroups)

head(group_table)

## ---- group_filter------------------------------------------------------------
number_of_samples <- nrow(srmExp@meta)

# Only keep groups with have Rt width of 3.0 minutes or less and total group occupancy is less than or equal to the total number of samples. 

group_table_filtered <-
  group_table %>% dplyr::filter(Rt >= 1.0 & Rt <= 16.0) %>%
  dplyr::filter(Rtwidth <= 3) %>% dplyr::filter(count <= number_of_samples)


## ---- plotGroup, fig.width = 8, fig.height = 4,  fig.align = 'center'---------
plotGroup(srmExpGroups, group = 'G001')

## ---- createGroup-------------------------------------------------------------
srmExpGroupTarg <- createGroup(srmExpPeaks, index = 1, rt = 3.2,  width = 30, id = 'Group01')

srmExpGroupTarg@groups

## ---- plotGroup2, fig.width = 6, fig.height = 6,  fig.align = 'center'--------
patchwork::wrap_plots(
  plotSRM(srmExpGroupTarg, index = 1),
  plotGroup(srmExpGroupTarg, group = 'Group01'),
  ncol = 1
)

## ---- accessor_methods--------------------------------------------------------
meta(srmExpGroups)

transitions(srmExpGroups)

peaks(srmExpGroups)

header(srmExpGroups)


